Seblod's Live CCK - Dynamic Default
===================

An Awesome solution if you Build Joomla+Seblod Site and sometime you feel limited by how do you set the default value in your site form OR in your Search Form.

Now you're about to be able to set your "default value" to

*** Drum Roll ****

..... Anything You Want, The Way You Want It !

 
How it work ?
--------------

1. You need to create file with function(s) that you need to use
2. You will registered the function and the path file in the configuration setting

That is, with the function you build you can set return $value to anything you want! and it can be use for Site Form and for customize the Search Query for your list
.. it's awesome isn't ?



Just if you feel some awesomeness after you install this plugin and you like to buy me
coffee (or XBOX... or iPhone)... my paypal is <b>victor@doxadigital.com</b>

if you donate, poke me, i'll give you credit and virtual hug ! 